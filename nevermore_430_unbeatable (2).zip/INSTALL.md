# Инструкция по установке Nevermore 1v1 Bot (v4.30 Unbeatable)

## 1. Куда распаковать файлы

Путь к папке ботов в вашей установке Dota 2:
```
<SteamLibrary>/steamapps/common/dota 2 beta/game/dota/scripts/vscripts/bots/
```
*(Если папок `scripts`, `vscripts` или `bots` нет — создайте их).*

Все файлы из архива должны находиться прямо в папке `bots/`:
```
dota/scripts/vscripts/bots/
├── bot_nevermore.lua
├── item_purchase_nevermore.lua
├── hero_selection.lua
├── team_desires.lua
├── bot_beastmaster.lua
├── item_purchase_beastmaster.lua
└── nevermore/
    ├── combat.lua
    ├── constants.lua
    ├── intent.lua
    ├── lane.lua
    ├── lasthit.lua
    ├── positioning.lua
    ├── souls.lua
    ├── utils.lua
    ├── version.lua
    ├── wave.lua
    └── world.lua
```

## 2. Как запустить 1v1 матч в Dota 2

1. В главном меню Dota 2: **Играть** -> **Пользовательские лобби** -> **Создать лобби**.
2. В настройках лобби:
   - **Режим игры**: `1v1 Solo Mid` (или `All Pick` с договорённостью идти только в мид без рун).
   - **Сервер**: `Локальный сервер` (Local Host) — **ОБЯЗАТЕЛЬНО**, чтобы скрипты подхватывались из вашей папки `vscripts/bots`.
   - **Боты**: выберите слот Radiant или Dire для бота (Nevermore).
3. Нажмите **Начать игру**.
